// Game state
let heelerCount = 0;
let heelersPerSecond = 0;
let clickPower = 1;

// Upgrade costs
let upgrade1Cost = 10;
let upgrade2Cost = 50;

// DOM elements
const heelerCountDisplay = document.getElementById('heeler-count');
const heelersPerSecondDisplay = document.getElementById('heelers-per-second');
const heelerImage = document.getElementById('heeler-image');
const upgrade1Button = document.getElementById('upgrade1');
const upgrade2Button = document.getElementById('upgrade2');
const upgrade1CostDisplay = document.getElementById('upgrade1-cost');
const upgrade2CostDisplay = document.getElementById('upgrade2-cost');

// --- Event Listeners ---

// Heeler image click
heelerImage.addEventListener('click', () => {
    heelerCount += clickPower;
    updateDisplay();
});

// Upgrade 1 click
upgrade1Button.addEventListener('click', () => {
    if (heelerCount >= upgrade1Cost) {
        heelerCount -= upgrade1Cost;
        clickPower++;
        upgrade1Cost = Math.ceil(upgrade1Cost * 1.5);
        updateDisplay();
    } else {
        alert('Not enough heelers!');
    }
});

// Upgrade 2 click
upgrade2Button.addEventListener('click', () => {
    if (heelerCount >= upgrade2Cost) {
        heelerCount -= upgrade2Cost;
        heelersPerSecond++;
        upgrade2Cost = Math.ceil(upgrade2Cost * 1.5);
        updateDisplay();
    } else {
        alert('Not enough heelers!');
    }
});


// --- Game Loop ---
setInterval(() => {
    heelerCount += heelersPerSecond;
    updateDisplay();
}, 1000);


// --- Utility Functions ---
function updateDisplay() {
    heelerCountDisplay.textContent = heelerCount;
    heelersPerSecondDisplay.textContent = heelersPerSecond;
    upgrade1CostDisplay.textContent = upgrade1Cost;
    upgrade2CostDisplay.textContent = upgrade2Cost;
}
